import Buttons from './components/Buttons';
import './App.css';
import { useState } from 'react';
function App(){
  let [calVal,setCalVal] = useState("");
  const handleBtnClick = (btnVal) => {
    if(btnVal === 'c'){
      setCalVal("");
    }else if(btnVal === '='){
      let result = eval(calVal);
      setCalVal(result);

    }else{
        let newValue = calVal+btnVal;
        setCalVal(newValue);
    }
  }
  return <div className='container'>
      <div>
        <input type="text" value={calVal} readOnly></input>
      </div>
      <div className='btnContainer'>
          <Buttons onBtnClick={handleBtnClick}></Buttons>
      </div>
  </div>
}
export default App;